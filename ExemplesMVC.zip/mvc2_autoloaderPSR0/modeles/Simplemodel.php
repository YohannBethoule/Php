<?php

namespace modeles;

class Simplemodel
{

//constructeur
//vide


function get_data()
{
return "Mon mod�le ne fait rien";
}

//fin mod�les
}
?> 