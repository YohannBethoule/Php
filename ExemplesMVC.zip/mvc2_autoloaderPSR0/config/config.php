<?php

//gen
$rep=__DIR__.'/../';

// liste des modules � inclure

//$dConfig['includes']= array('controleur/Validation.php');



//BD

$base="sasa";
$login="";
$mdp="";

//Vues

$vues['erreur']='vues/erreur.php';
$vues['vuephp1']='vues/vuephp1.php';


?>